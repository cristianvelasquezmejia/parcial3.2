using Microsoft.EntityFrameworkCore;

namespace PrParcial.Models
{
    public class TaskContext:DbContext
    {
        public TaskContext(DbContextOptions<TaskContext>  options) :
        base (options)
{
}
public DbSet <RutaItem> RutaItems { get ; set ;}
public DbSet <ClienteItem> ClienteItems { get ; set ;}
public DbSet <TiqueteItem> TiqueteItems { get ; set ;}

    }
}
import { FiltroRutasPipe } from './filtro-rutas.pipe';

describe('FiltroRutasPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroRutasPipe();
    expect(pipe).toBeTruthy();
  });
});

import { FiltroEjemploPipe } from './filtro-ejemplo.pipe';

describe('FiltroEjemploPipe', () => {
  it('create an instance', () => {
    const pipe = new FiltroEjemploPipe();
    expect(pipe).toBeTruthy();
  });
});

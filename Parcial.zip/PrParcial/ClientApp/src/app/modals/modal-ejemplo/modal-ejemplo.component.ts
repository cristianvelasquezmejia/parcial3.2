import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-ejemplo',
  templateUrl: './modal-ejemplo.component.html',
  styleUrls: ['./modal-ejemplo.component.css']
})
export class ModalEjemploComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

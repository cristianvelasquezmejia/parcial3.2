import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alerta-modal',
  templateUrl: './alerta-modal.component.html',
  styleUrls: ['./alerta-modal.component.css']
})
export class AlertaModalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

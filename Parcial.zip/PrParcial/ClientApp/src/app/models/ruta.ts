export class Ruta {
    id_ruta:number;
    origen:string;
    destino:string;
    valor:number;
}

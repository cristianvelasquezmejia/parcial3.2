export class Tiquete {
    id:number;
    id_cliente:string;
    id_ruta:number;
    cantidad:number;
    total:number;
}


export class Areolinea {
    id:number;
    origen:string;
    destino:string;
    valor:number;
}

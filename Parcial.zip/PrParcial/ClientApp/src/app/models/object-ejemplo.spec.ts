import { ObjectEjemplo } from './object-ejemplo';

describe('ObjectEjemplo', () => {
  it('should create an instance', () => {
    expect(new ObjectEjemplo()).toBeTruthy();
  });
});

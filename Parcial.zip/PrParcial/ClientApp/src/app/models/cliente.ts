export class Cliente {
    id_cliente:number;
    nombre:string;
}

import { Tiquete } from './tiquete';

describe('Tiquete', () => {
  it('should create an instance', () => {
    expect(new Tiquete()).toBeTruthy();
  });
});

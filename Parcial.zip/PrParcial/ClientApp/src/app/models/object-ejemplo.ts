export class ObjectEjemplo {
    id:number;
    nombre:string;
}

import { Ruta } from './ruta';

describe('Ruta', () => {
  it('should create an instance', () => {
    expect(new Ruta()).toBeTruthy();
  });
});

import { Areolinea } from './areolinea';

describe('Areolinea', () => {
  it('should create an instance', () => {
    expect(new Areolinea()).toBeTruthy();
  });
});
